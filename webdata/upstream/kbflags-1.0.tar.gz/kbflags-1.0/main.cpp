
//
// KBFlags
//
// KBFlags creates icons with flap effect.
//
// Copyright (C) 2005 Andi Peredri <andi@ukr.net>
//
// Compilation: qmake; make
//
// Usage:	Put source images into "21x14" directory and
//		run mkflags from the parent directory. The created
//		icons will be placed into "21x14.new" directory.
//
// Description: KBFlags creates two waves if the size of the icons
//		is sufficient.
//
// Homepage:	http://qt.osdn.org.ua/kbflags.html
// License:	GNU General Public License
//


#include <qdir.h>
#include <qimage.h>
#include <iostream>


// Main ---------------------------------------------------------------------

int main(int, char**)
{
    QDir sdir("21x14");
    sdir.setFilter(QDir::Files);
    qWarning("Source directory: %s", sdir.absPath().ascii());

    QDir tdir(sdir.absPath() + ".new");
    if(!tdir.exists() && !tdir.mkdir(tdir.absPath()))
    {
	qWarning("Could not create target directory: %s\nExited...",
	    tdir.absPath().ascii());
        return 1;
    }
    qWarning("Target directory: %s", tdir.absPath().ascii());

    int counter = 0;
    for(unsigned file = 0; file < sdir.count(); file++)
    {
        QString sfilename = sdir.absPath() + "/" + sdir[file];
        QString tfilename = tdir.absPath() + "/" + sdir[file];

	QImage image(sfilename);
	if(image.isNull())
	{
	    qWarning("\nCould not load image: %s", sfilename.ascii());
            continue;
	}

	int x1 = image.height() / 3;

	for(int y = 0; y < image.height(); y++)
	{
	    QRgb* line = (QRgb*)image.scanLine(y);
	    for(int wave = 0; wave < 2; wave++)
	    {
		for(int phase = 0; phase < 2; phase++)
		{
		    int x0 = (2 * wave + phase) * x1 + image.height() / 6;
		    for(int x = 0; x < x1; x++)
		    {
			if((x0 + x) >= image.width()) continue;

			QRgb pix = line[x0 + x];

			int r0 = qRed(pix);
			int g0 = qGreen(pix);
			int b0 = qBlue(pix);

			if(qAlpha(pix) == 255)
			{
			    int x2 = phase ? (x1 - x) : x;

			    int r = r0 - x2 * r0 / (4 * x1);
			    int g = g0 - x2 * g0 / (4 * x1);
			    int b = b0 - x2 * b0 / (4 * x1);

			    line[x0 + x] = qRgb(r, g, b);
			}
		    }
		}
	    }
	}

	if(!image.save(tfilename, "PNG"))
	    qWarning("\nCould not save image: %s", tfilename.ascii());
	else
	{
	    putchar('.');
	    fflush(stdout);
	    counter++;
	}
    }
    qWarning("\n%d icons saved.", counter);

    return 0;
}

